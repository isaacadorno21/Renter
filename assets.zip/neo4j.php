<?php

use Neoxygen\NeoClient\ClientBuilder;

$connUrl = parse_url('https://hobby-cgekkedekdmngbkeidknkedl.dbs.graphenedb.com:24780/db/data/');


$user = 'renter';
$pwd = 'b.zbAF0Xm2u2tq.zC0UtcV3JmRuHfpL';

$client = ClientBuilder::create()
  ->addConnection('default', $connUrl['scheme'], $connUrl['host'], $connUrl['port'], true, $user, $password)
  ->build();

$client->run('CREATE (n:User)');
?>