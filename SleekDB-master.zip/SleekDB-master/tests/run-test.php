<?php
  // Run the "Nest" testing utility.
  require_once './nest/Nest.php';
  (new Nest(__DIR__))->runTest();