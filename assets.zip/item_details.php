<?php 
  session_start();
?>

<!DOCTYPE HTML>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Renter</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
	<link href="assets/css/main.css" rel="stylesheet" /><noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
</head>
<body class="is-preload"><!-- Wrapper -->
<div id="wrapper"><!-- Header -->
<header id="header">
<h1>Rent Item</h1>
</header>
<nav id="nav">
<ul>
	<li><a href="home_page.php">Home Page</a></li>
	<li><a class=#active href="my_items.php">My Items</a></li>
	<li><a href="loaned_items.php">Loaned Items</a></li>
	<li><a href="account.php">Account</a></li>
</ul>
</nav>
<!-- Main -->

<div id="main"><!-- Introduction -->

<?php
    if (isset($_SESSION['username'])) {
        echo "<strong>";
        echo "Current User: ".$_SESSION['username'];
        echo "<br>User ID: ".$_SESSION['user_id'];
        echo "<br>Item ID: ".$_SESSION['item_id'];
        echo "</strong>";
    }
?>

<form method="post">
<input type="submit" name="sign_out" value="Sign Out">
</form>

<?php
    if (isset($_POST['sign_out'])) {
        // remove all session variables
        session_unset();
        // destroy the session
        session_destroy();
        echo "<script> location.href='index.html'; </script>";
    }
?>

<br>

<form method="post">
<input type="submit" name="submit" value="Rent Item">
</form> 

<?php
  
    $servername = "localhost";
    $username = "uiucrenter_mainuser";
    $password = "uiucrenter_mainuser";
    $database = "uiucrenter_main";
    
    $cur_user_id = $_SESSION['user_id'];
    $cur_item = $_SESSION['item_id'];
    
    // Create connection
    $mysqli = mysqli_connect($servername, $username, $password, $database);

    if (mysqli_connect_errno($mysqli)) {
       echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    
    
    if(isset($_POST['submit'])) {
       
      /*REMOVE ME WHEN RENTEE STRUCTURE IS FIXED*/
       $rating = 3;

    
        //UPDATE RENTEE TABLE--------------------------------------------------
        
        //check if rentee already exists in table 
        $sqlinsert = "INSERT INTO Rentee (user_id, rentee_rating) VALUES ('$cur_user_id', '$rating')";
        
        if (mysqli_query($mysqli, $sqlinsert)) {
                   echo "New rentee record created successfully. But you need to differentiate user id and rentee id and pass in rentee rating cool thx"."<br/>";
        }
        else {
            echo "rentee failed";
        }
        
        //UPDATE OWNER TABLE---------------------------------------------------
        //GET OWNER------------------------------------------------------------
        $sqlselect = "SELECT owner_id FROM Items WHERE $cur_item = Items.item_id";
         if ($result = mysqli_query($mysqli, $sqlselect)) {
             while($row = mysqli_fetch_assoc($result)){
                $ownerid = $row["owner_id"];
             }
             echo "owner grabbed ";
        }
        else {
            echo "owner not grabbed";
            echo "$ownerid";
        }
        
        //GET DATE-------------------------------------------------------------
            $date = date('Y-m-d');
        
       //UPDATE LOANS TABLE----------------------------------------------------
       $sqlinsertl= "INSERT INTO Loans (owner_id, rentee_id, item_id, rented_date) VALUES
           ('$ownerid', '$cur_user_id', '$cur_item', '$date')";
           
        if (mysqli_query($mysqli, $sqlinsertl)) {
                   echo "New loans record created successfully"."<br/>";
                 //  echo "<script> location.href='item_confirmation.php'; </script>";
        }
        else {
            echo "loans failed";
            echo "$ownerid ";
            echo "$cur_user_id ";
            echo "$cur_item ";
            echo "$date ";
        }
        
            
    }
    
?>
<br><br>

</div>
<!-- Footer -->

<footer id="footer">

<p class="copyright">Created by UIUC CS411 students - Renter</p>
</footer>
</div>
<!-- Scripts --><script src="assets/js/jquery.min.js"></script><script src="assets/js/jquery.scrollex.min.js"></script><script src="assets/js/jquery.scrolly.min.js"></script><script src="assets/js/browser.min.js"></script><script src="assets/js/breakpoints.min.js"></script><script src="assets/js/util.js"></script><script src="assets/js/main.js"></script></body>
</html>